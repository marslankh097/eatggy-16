/*
 * Copyright (c) 2021.  Hurricane Development Studios
 */

package com.example.ars.model;

import androidx.fragment.app.Fragment;

import com.example.ars.VDApp;
import com.example.ars.activity.MainActivity;

public class VDFragment extends Fragment {

    public MainActivity getVDActivity() {
        return (MainActivity) getActivity();
    }

    public VDApp getVDApp() {
        return (VDApp) getActivity().getApplication();
    }
}
