/*
 * Copyright (c) 2021.  Hurricane Development Studios
 */

package com.example.ars.download;

public interface Tracking {
    void startTracking();
    void stopTracking();
}
